"""Generated from frozen fullpack methods; do not hand edit."""
from __future__ import annotations
import numpy as np
from .domain import BattleOutcome
from .engine import Transition

class Observation:
    def _observation(self) -> Dict[str, np.ndarray]:
        state = self.engine.state
        config = self.engine.config
        previous = 0.0 if state.previous_outcome is None else (int(state.previous_outcome) + 1) / 2
        gold_bound = max(config.starting_gold * 2, 1)
        if self.engine.expanded_rules:
            gold_bound = config.starting_gold + config.max_team_size * 3 + config.max_actions_per_turn * 6
        global_obs = np.asarray([min(state.turn / config.max_turns, 1.0), min(state.gold / gold_bound, 1.0), min(state.lives / config.starting_lives, 1.0), min(state.wins / config.target_wins, 1.0), min(state.actions_this_turn / config.max_actions_per_turn, 1.0), previous, float(state.previous_outcome is not None), min(self.engine.unlocked_tier / 6, 1.0)], dtype=np.float32)
        if self.engine.midgame_rules:
            global_obs[1] = state.gold / (state.gold + 10)
        if self.observe_episode_actions:
            maximum = config.max_turns * config.max_actions_per_turn
            global_obs = np.append(global_obs, np.float32(min(self.episode_actions / maximum, 1.0)))
        if self.engine.tier4_rules:
            global_obs = np.append(global_obs, np.asarray([state.shop_attack_bonus / 50, state.shop_health_bonus / 50], dtype=np.float32))
        team = np.zeros(self.observation_space['team'].shape, dtype=np.float32)
        pet_count = len(self._pet_index)
        for (row, pet) in enumerate(state.team):
            team[row, 0] = 1.0
            team[row, 1 + self._pet_index[pet.spec_id]] = 1.0
            offset = 1 + pet_count
            team[row, offset:offset + 8] = np.asarray([min(pet.attack / 50, 1.0), min(pet.health / 50, 1.0), pet.level / 3, pet.experience / 6, min(pet.temporary_attack / 50, 1.0), min(pet.temporary_health / 50, 1.0), float(pet.perk == 'honey'), row / max(config.max_team_size - 1, 1)], dtype=np.float32)
            if self.engine.expanded_rules:
                team[row, offset + 8:offset + 11] = [float(pet.perk == 'meat_bone'), float(pet.perk == 'melon'), min(pet.ability_uses / (5 if self.engine.fullpack_rules else 3), 1.0)]
            if self.engine.midgame_rules:
                start = offset + 11
                team[row, start:start + 4] = [float(pet.perk == 'garlic'), float(pet.perk == 'chili'), float(pet.perk == 'cake'), pet.sell_bonus / (pet.sell_bonus + 1)]
                if pet.copied_ability is not None:
                    team[row, start + 4 + self._pet_index[pet.copied_ability]] = 1.0
            if self.engine.tier4_rules:
                start = team.shape[1] - (5 if self.engine.fullpack_rules else 2)
                team[row, start:start + 2] = [float(pet.perk == 'peanut'), float(pet.perk == 'bread')]
            if self.engine.fullpack_rules:
                team[row, -3:] = [float(pet.perk == p) for p in ('coconut', 'mushroom', 'steak')]
        shop = np.zeros(self.observation_space['shop'].shape, dtype=np.float32)
        combined_count = len(self._pet_index) + len(self._food_index)
        for (row, item) in enumerate(state.shop):
            if item is None:
                continue
            shop[row, 0] = 1.0
            if item.kind == 'pet':
                item_index = self._pet_index[item.item_id]
                tier = self.engine.catalog.pets[item.item_id].tier
                shop[row, 1 + combined_count + 1] = 1.0
            else:
                item_index = len(self._pet_index) + self._food_index[item.item_id]
                tier = self.engine.catalog.foods[item.item_id].tier
                shop[row, 1 + combined_count + 2] = 1.0
            shop[row, 1 + item_index] = 1.0
            offset = 1 + combined_count
            shop[row, offset] = min(item.cost / 10, 1.0)
            shop[row, offset + 3] = float(item.frozen)
            shop[row, offset + 4] = tier / 6
            if config.shop_pet_stats and item.kind == 'pet':
                pet = item.pet
                if pet is None:
                    from .engine import make_pet
                    pet = make_pet(self.engine.catalog, item.item_id)
                shop[row, offset + 5:offset + 11] = np.asarray([min(pet.attack / 50, 1.0), min(pet.health / 50, 1.0), pet.experience / 6, min(pet.temporary_attack / 50, 1.0), min(pet.temporary_health / 50, 1.0), float(pet.perk == 'honey')], dtype=np.float32)
            if self.engine.modern_shop and item.choice_group is not None:
                for (other_row, other) in enumerate(state.shop):
                    if other is not None and other.choice_group == item.choice_group:
                        shop[row, offset + 11 + other_row] = 1.0
            if self.engine.expanded_rules and item.kind == 'pet' and (item.pet is not None):
                start = offset + 11 + config.max_shop_size
                shop[row, start:start + 3] = [float(item.pet.perk == 'meat_bone'), float(item.pet.perk == 'melon'), min(item.pet.ability_uses / (5 if self.engine.fullpack_rules else 3), 1.0)]
                if self.engine.midgame_rules:
                    start += 3
                    pet = item.pet
                    shop[row, start:start + 4] = [float(pet.perk == 'garlic'), float(pet.perk == 'chili'), float(pet.perk == 'cake'), pet.sell_bonus / (pet.sell_bonus + 1)]
                    if pet.copied_ability is not None:
                        shop[row, start + 4 + self._pet_index[pet.copied_ability]] = 1.0
                if self.engine.tier4_rules:
                    start = shop.shape[1] - (5 if self.engine.fullpack_rules else 2)
                    shop[row, start:start + 2] = [float(item.pet.perk == 'peanut'), float(item.pet.perk == 'bread')]
                if self.engine.fullpack_rules:
                    shop[row, -3:] = [float(item.pet.perk == p) for p in ('coconut', 'mushroom', 'steak')]
        return {'global': global_obs, 'team': team, 'shop': shop}

def finish_battle(self, result):
    self.last_battle = result
    opponent = []
    outcome = self.last_battle.outcome
    self.state.previous_outcome = outcome
    if outcome is BattleOutcome.WIN:
        self.state.wins += 1
    elif outcome is BattleOutcome.LOSS:
        self.state.lives -= 1
    for pet in self.state.team:
        pet.clear_temporary_stats()
    self.state.terminated = self.state.wins >= self.config.target_wins or self.state.lives <= 0
    info: Dict[str, Any] = {'battle_outcome': outcome.name.lower(), 'opponent': [pet.spec_id for pet in opponent], 'battle_trace': list(self.last_battle.trace)}
    if self.expanded_rules and self.catalog.battle_attack_limit is not None:
        info['battle_attacks'] = self.last_battle.attacks
        info['battle_attack_limit_reached'] = self.last_battle.attack_limit_reached
    if self.state.terminated:
        info['success'] = self.state.wins >= self.config.target_wins
        return Transition(float(outcome), True, False, info)
    self.state.turn += 1
    if self.state.turn > self.config.max_turns:
        self.state.truncated = True
        info['reason'] = 'turn_limit'
        return Transition(float(outcome), False, True, info)
    self.state.gold = self.config.starting_gold
    self.state.actions_this_turn = 0
    if self.expanded_rules:
        for pet in self.state.team:
            pet.ability_uses = 0
        if self.state.turn == 3 and self.state.lives < self.config.starting_lives:
            self.state.lives += 1
    self._roll_shop(free=True)
    if self.expanded_rules:
        self._shop_runtime().phase('start_turn')
    return Transition(float(outcome), False, False, info)
